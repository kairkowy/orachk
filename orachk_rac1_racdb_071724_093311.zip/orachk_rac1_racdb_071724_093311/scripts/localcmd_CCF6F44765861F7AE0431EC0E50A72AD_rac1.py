#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_CCF6F44765861F7AE0431EC0E50A72AD_rac1.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_CCF6F44765861F7AE0431EC0E50A72AD_rac1.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import sys
import os
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/u01/app/oracle/orachk//orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['ORACLE_HOME'] = "/u01/app/oracle/product/19c/db_1"
os.environ['ORACLE_SID'] = "racdb1"
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'

ALVL = '''FAIL'''
native_code = '''
status=0
TOTAL_HUGEPAGES=$(grep HugePages_Total /proc/meminfo | cut -d":" -f 2 | sed -e \'s/^[ \t]*//;s/[ \t]*$//\')
HPG_SZ=$(grep Hugepagesize /proc/meminfo | awk \'{print $2}\')
NUM_PG=0
MGMT_PID=$(/usr/bin/pgrep -f mdb_pmon_)
if [ $? -eq 0 ]; then
 MGMT_SEGIDS=$(grep SYSV /proc/${MGMT_PID}/maps  | awk  \'{print $5}\' | uniq)
else
 MGMT_PID=0
fi
IPCARR=($(ipcs -m |  grep "^0x" | awk \'{ print $2":"$5}\'))
for SEGIDBYTES in "${IPCARR[@]}"
 do
  SEG_ID=${SEGIDBYTES%:*}
  SEG_BYTES=${SEGIDBYTES##*:}
  if  [[ $MGMT_PID -eq 0 || ! "$MGMT_SEGIDS" =~ "$SEG_ID" ]]; then
   MIN_PG=$(echo "$SEG_BYTES/($HPG_SZ*1024)" | bc -q)
   if [ $MIN_PG -gt 0 ]; then
      NUM_PG=$(echo "$NUM_PG+$MIN_PG+1" | bc -q)
   fi
  fi
done
NUM_PGX=$(echo "$NUM_PG * 1.008" |bc -q )
if [ $(uname -p) == "sparc64" ] ; then
    if [ $TOTAL_HUGEPAGES -ge $NUM_PG ]
    then
        report_command="Total current hugepages ($TOTAL_HUGEPAGES) are greater than or equal to estimated requirements for all currently active SGAs ($NUM_PG)"
    else
         status=1
          report_command="Total current hugepages ($TOTAL_HUGEPAGES) should be greater than or equal to estimated requirements for all currently active SGAs ($NUM_PG ).Set HugePages to ($(printf "%.0f\n" $NUM_PGX))"
    fi
else
   if [ $TOTAL_HUGEPAGES -ge $NUM_PG ]
      then 
           report_command="Total current hugepages ($TOTAL_HUGEPAGES) are greater than or equal to estimated requirements for all currently active SGAs ($NUM_PG)"
      else 
           status=1
           report_command="Total current hugepages ($TOTAL_HUGEPAGES) should be greater than or equal to estimated requirements for all currently active SGAs ($NUM_PG )"
    fi
fi
echo "$status"
echo DELIMCOM;echo -e "$report_command"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/u01/app/oracle/orachk//orachk_071724_093311/CCF6F44765861F7AE0431EC0E50A72AD_rac1_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
