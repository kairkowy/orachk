#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_C31B975819621D1CE0431EC0E50AC731_rac1.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_C31B975819621D1CE0431EC0E50AC731_rac1.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import os
import sys
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/u01/app/oracle/orachk//orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'
os.environ["ORACLE_SID"] = 'racdb1'
os.environ["ORACLE_HOME"] = '/u01/app/oracle/product/19c/db_1'

ALVL = '''WARNING'''
native_code = '''
COMMAND_OUTPUT=$(function logswitches {
$ORACLE_HOME/bin/sqlplus -s \'/ as sysdba\' <<EOF
set feedback off newpage none termout on
alter session set nls_date_format=\'YYYY/MM/DD HH24:MI:SS\';
select * from (
select thread#,sequence#,first_time "LOG START TIME",(blocks*block_size/1024/1024)/((next_time-first_time)*86400) "REDO RATE(MB/s)", \
(((blocks*block_size)/a.average)*100) pct_full
from v\$archived_log, (select avg(bytes) average from v\$log) a
where ((next_time-first_time)*86400<300)
and first_time > (sysdate-90)
and (((blocks*block_size)/a.average)*100)>80
and dest_id=1
order by 4 desc
)
where rownum<11;
exit
EOF
}

export SWITCHES=$(logswitches)

if [ $(echo "$SWITCHES"| wc -l) -le 1 ]
 then
  echo -e "SUCCESS: Redo logs are appropriately sized"
 else
  echo
  echo -e "WARNING: Redo logs are potentially mis-sized.  Below is a list of archived logs from"
  echo -e "the previous 90 days which were active for less than 5 minutes and the redo rate seen"
  echo -e "for the duration of that log.  These indicate the peak redo rate. Resizing of the log"
  echo -e "files to accomodate this rate may be required.\n"
  echo "$SWITCHES"
fi)
if [ `echo $COMMAND_OUTPUT | grep -wc "SUCCESS:"` -eq 1 ]
then
  echo 0
else
  echo 1
fi
echo DELIMCOM;echo "$COMMAND_OUTPUT"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/u01/app/oracle/orachk//orachk_071724_093311/C31B975819621D1CE0431EC0E50AC731_rac1_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
