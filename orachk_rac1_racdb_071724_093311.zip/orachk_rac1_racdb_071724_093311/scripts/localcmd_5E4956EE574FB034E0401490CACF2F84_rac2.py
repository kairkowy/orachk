#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_5E4956EE574FB034E0401490CACF2F84_rac2.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_5E4956EE574FB034E0401490CACF2F84_rac2.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import sys
import os
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/home/oracle/.orachk_071724_093311/orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['ORACLE_HOME'] = "/u01/app/oracle/product/19c/db_1"
os.environ['ORACLE_SID'] = "racdb1"
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'
os.environ["OUTPUTDIR"] = "/home/oracle/.orachk_071724_093311/orachk_071724_093311/"

ALVL = '''INFO'''
native_code = '''
status=0
AWK=/bin/gawk
cpu_model=$(grep -wi "Intel(R)" /proc/cpuinfo|sort -u|$AWK \'BEGIN{FS="CPU"}{print $2}\'|$AWK \'BEGIN{FS="@"}{print $1}\'|tr -d \' \'|sed \'/^$/d\')
interconnect_netname=$($CRS_HOME/bin/oifcfg getif|grep cluster_interconnect|tail -1|awk \'{print $1}\' 2>/dev/null)
ifconfig_output=$(/sbin/ifconfig $interconnect_netname 2>/dev/null)
mtu_size=$(echo "$ifconfig_output"|grep -i mtu|cut -d: -f2|awk \'{print $1}\')
if [[ $mtu_size  =~ [^[:digit:]] ]]
then
       mtu_size=$(echo "$ifconfig_output"|grep -i mtu|awk \'{print $NF}\')
fi
ib_or_eth=$(echo "$ifconfig_output"|grep -wc InfiniBand)
if [[ -n "$ib_or_eth" && $ib_or_eth -eq 0 ]]
then
      if [[ "$mtu_size" && $mtu_size -lt 9000 ]];then status=1;fi    
else
            if [[ "$mtu_size" && $mtu_size -lt 7000 ]];then status=1;fi   
fi
if [ -n "$cpu_model" ] && [[ "$cpu_model" = "E5-2699v3" || "$cpu_model" = "E5-2699v4" ]]; then status=9196;fi
echo $status
echo DELIMCOM;echo -e "CPU Model = $cpu_model\n\n$ifconfig_output"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/home/oracle/.orachk_071724_093311/orachk_071724_093311/5E4956EE574FB034E0401490CACF2F84_rac2_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
