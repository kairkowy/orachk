#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_53BAB95BC9B1D1D4E0530B98EB0AD1BA_rac1.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_53BAB95BC9B1D1D4E0530B98EB0AD1BA_rac1.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import sys
import os
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/u01/app/oracle/orachk//orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'
os.environ["ORACLE_SID"] = '+ASM1'
os.environ["ORACLE_HOME"] = '/u01/app/19c/grid'

ALVL = '''WARNING'''
native_code = '''
count=0
total_disk_groups=0
gi_version=$($CRS_HOME/bin/crsctl query crs activeversion)
gi_version_short=$(echo "$gi_version"|sed \'s/[^0-9]//g\')
gi_version5=$(echo  ${gi_version_short:0:5})
for asm_compatible  in $(cat $RTEMPDIR/a_dbm_asm_diskgroup_attributes_dbmv2.out 2>/dev/null|grep -v template|grep "compatible\.advm"|cut -d= -f2|sed \'s/ //g\'|sed \'s/\.//g\')
do
  total_disk_groups=$(expr $total_disk_groups + 1)
  asm_compatible5=$(echo ${asm_compatible:0:5})
  if [[ $asm_compatible5 -eq $gi_version5 ]]
  then
      continue
  else
      count=$(expr $count + 1)
  fi
done
if [ $total_disk_groups -eq 0 ]
then
        count=$(expr $count + 1)
fi
echo $count
echo DELIMCOM;report_command=$(cat $RTEMPDIR/a_dbm_asm_diskgroup_attributes_dbmv2.out 2>/dev/null|grep -v template|grep "compatible\.advm")
if [ -z "$report_command" ]
then
      report_command="None of the diskgroups have compatible.advm attribute set"
fi 
echo -e "$gi_version\n\n$report_command"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/u01/app/oracle/orachk//orachk_071724_093311/53BAB95BC9B1D1D4E0530B98EB0AD1BA_rac1_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
