#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_429C554ED92E4F54E0530D98EB0AE367_rac2.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_429C554ED92E4F54E0530D98EB0AE367_rac2.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import os
import sys
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/home/oracle/.orachk_071724_093311/orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'
os.environ["OUTPUTDIR"] = "/home/oracle/.orachk_071724_093311/orachk_071724_093311/"
os.environ["ORACLE_SID"] = 'racdb2'
os.environ["ORACLE_HOME"] = '/u01/app/oracle/product/19c/db_1'

ALVL = '''FAIL'''
native_code = '''
is_rds=$($ORACLE_HOME/bin/skgxpinfo)
if [ "$is_rds" = "udp" ]
then
      final_status=9196
else
      cluster_interconnects=$(echo -e "set heading off feedback off timing off \n select value from v\$parameter where name=\'cluster_interconnects\';"|$ORACLE_HOME/bin/sqlplus -s "/ as sysdba"|tr -d \'\n\')
     for bondnet in $($CRS_HOME/bin/oifcfg getif -type cluster_interconnect|awk \'{print $1}\')
     do 
         bondnet=$(/sbin/ifconfig $bondnet 2>/dev/null|grep -w "inet"|awk \'{print $2}\'|cut -d: -f2)
        status=$(echo $cluster_interconnects|grep -c $bondnet)
        if [ $status -eq 0 ]
        then
               final_status=1
               break
        else
            final_status=0
        fi
    done
fi
echo $final_status
echo DELIMCOM; unset bondnet_output;final_output=$(echo -e "\nCluster Interconnect Value from instance = $cluster_interconnects\n\nNetwork card name and IP from oifcfg");for bondnet in $($CRS_HOME/bin/oifcfg getif -type cluster_interconnect|awk \'{print $1}\'); do bondnet_output=$(echo -e "$bondnet_output \n$bondnet = $(/sbin/ifconfig $bondnet 2>/dev/null|grep -w "inet"|awk \'{print $2}\'|cut -d: -f2)"); done;echo -e "$final_output $bondnet_output"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/home/oracle/.orachk_071724_093311/orachk_071724_093311/429C554ED92E4F54E0530D98EB0AE367_rac2_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
