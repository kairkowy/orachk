#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_135F449E978C3B44E05313C0E50ABE53_rac1.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_135F449E978C3B44E05313C0E50ABE53_rac1.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import sys
import os
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/u01/app/oracle/orachk//orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['ORACLE_HOME'] = "/u01/app/oracle/product/19c/db_1"
os.environ['ORACLE_SID'] = "racdb1"
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'

ALVL = '''WARNING'''
native_code = '''
status=0
MASTERENVFILE=$OUTPUTDIR/raccheck_env.out
total_mem="$(cat /proc/meminfo |grep MemTotal |awk \'{print $2 * 1024}\')"
total_huge_pages=$(grep -w HugePages_Total: /proc/meminfo| awk \'{print $2}\')
huge_page_size=$(grep -w Hugepagesize /proc/meminfo| awk \'{print $2 * 1024}\')
total_huge_pages_memory=$(echo "$total_huge_pages $huge_page_size"|awk \'{print $1 * $2}\')
non_huge_page_memory=$(echo "$total_mem $total_huge_pages_memory"|awk \'{print $1 - $2}\')
total_pga_memory=0
for param_file in $(ls -l $OUTPUTDIR/*_v_parameter_*|grep -v v_parameter_u|awk \'{print $NF}\')
do
   #echo $param_file
   asm_instance_file=$(echo $param_file|grep -ic asm)
   pga_aggregate_limit_found=$(egrep -wc pga_aggregate_limit $param_file)
   param_db_name=$(egrep -wi db_name $param_file|awk \'{print $NF}\'|uniq)
   #echo $param_db_name
   env_has_map=$(grep -iwc map $MASTERENVFILE)
   if [ $env_has_map -gt 0 ]
   then
      inst_host_name=$(egrep -wi MAP $MASTERENVFILE|grep $(hostname -s)|tail -1|cut -d= -f1|cut -d: -f2|tr -d \' \')
   else
      inst_host_name=$(hostname -s)
   fi
   inst_grep_expr=$(echo $inst_host_name.$param_db_name.INSTANCE_NAME)
   if [ $asm_instance_file -gt 0 ]
   then
       param_inst_name=$(ps -ef|grep asm_pmon|grep -v grep |awk \'{print $NF}\'|cut -d_ -f3)
   else
       param_inst_name=$(egrep -wi "$inst_grep_expr" $MASTERENVFILE|awk \'{print $NF\'})
   fi
   if [ -n "$param_inst_name" ]
   then
       if [ $pga_aggregate_limit_found -gt 0 ]
       then
           pga_size=$(egrep -w "$param_inst_name.pga_aggregate_limit" $param_file|awk \'{print $NF}\'|uniq)
       else
           pga_size=$(egrep -w "$param_inst_name.pga_aggregate_target" $param_file|awk \'{print $NF}\'|uniq)
           if [ -n "$pga_size" ]; then pga_size=$(echo "$pga_size * 3"|bc);fi
       fi
   fi
   #echo $pga_size
if [[ -n "$pga_size" && $pga_size -gt 0 ]]; then total_pga_memory=$(perl -e "printf \"%.0f\", $total_pga_memory+$pga_size");fi
#read -p "stop"
done
#echo $total_pga_memory
if [ $non_huge_page_memory -le $total_pga_memory ];then status=1;fi
echo $status
echo DELIMCOM;total_mem=$(echo "$total_mem/1024/1024"|bc)
total_huge_pages_memory=$(echo "$total_huge_pages_memory/1024/1024"|bc)
non_huge_page_memory=$(echo "$non_huge_page_memory/1024/1024"|bc)
total_pga_memory=$(echo "$total_pga_memory/1024/1024"|bc)
echo -e "Total memory on $(hostname) = $total_mem MB\nTotal memory allocated to hugepages = $total_huge_pages_memory MB\nTotal available memory for PGA allocation = $non_huge_page_memory MB\nMemory allocated to all PGAs = $total_pga_memory MB\n\n"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/u01/app/oracle/orachk//orachk_071724_093311/135F449E978C3B44E05313C0E50ABE53_rac1_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
