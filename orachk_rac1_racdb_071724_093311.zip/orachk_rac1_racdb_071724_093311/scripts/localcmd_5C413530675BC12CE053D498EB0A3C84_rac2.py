#!/bin/env python
'''
        To run this script, follow below steps:
        1) mkdir -p /home/oracle/.orachk_071724_093311/
        2) cp -r SCRIPTPATH/lib /home/oracle/.orachk_071724_093311/; cp -r SCRIPTPATH/build/Python37 /home/oracle/.orachk_071724_093311/
        3) cp collndir/scripts/localcmd_5C413530675BC12CE053D498EB0A3C84_rac2.py /home/oracle/.orachk_071724_093311/
        4) /home/oracle/.orachk_071724_093311//Python37/bin/python /home/oracle/.orachk_071724_093311//localcmd_5C413530675BC12CE053D498EB0A3C84_rac2.py

        To rollback above changes, follow below step:
        1) rm -rf /home/oracle/.orachk_071724_093311/
        '''
from __future__ import print_function, unicode_literals
import os
import sys
sys.path.insert(0, '/home/oracle/.orachk_071724_093311/')
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("localcmd", '/home/oracle/.orachk_071724_093311/orachk_071724_093311/orachk.log', 'INFO', '')
secure = Secure(arg_logger = _logger)
os.environ["RUN_USER"] = 'oracle'
import os, sys, re
from lib.utils import Utils
from lib.constant import Constants
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'
os.environ['CRS_HOME'] = "/u01/app/19c/grid"
os.environ['OUTPUTDIR'] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ['TMPDIR'] = "/home/oracle/.orachk_071724_093311/"
os.environ['RTEMPDIR'] = "/home/oracle/.orachk_071724_093311/"
if re.search(r'unset', os.environ.get('LD_LIBRARY_PATH','')): os.environ['LD_LIBRARY_PATH'] = ""
os.environ['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', "") + ':' + os.environ.get('ORACLE_HOME', "") + os.path.sep + 'lib' + ':' + os.environ.get('CRS', "") + os.path.sep + 'lib'
os.environ["OUTPUTDIR"] = "/home/oracle/.orachk_071724_093311/orachk_071724_093311/"
os.environ["ORACLE_SID"] = 'racdb2'
os.environ["ORACLE_HOME"] = '/u01/app/oracle/product/19c/db_1'

ALVL = '''FAIL'''
native_code = '''
v_is_loc_shared=1
if [ -e /bin/awk ] ; then
 v_awk=/bin/awk
elif [ -e /usr/xpg4/bin/awk ] ; then
 v_awk=/usr/xpg4/bin/awk
else
 v_awk=awk
fi
export CV_DESTLOC=$TMP_OUTPUT
# get the db snapcf config info
v_snapcf_loc=$(echo -e "set heading off feedback off linesize 500 timing off \nselect distinct value from v\$rman_configuration where name=\'SNAPSHOT CONTROLFILE NAME\';"|$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" | $v_awk -F"\'" \'{print $2}\' | tr -d \' \')

# get the hosts on which this db\'s instances are running
v_hosts=$(echo -e "set heading off feedback off linesize 500 timing off \nselect distinct host_name from gv\$instance;"|$ORACLE_HOME/bin/sqlplus -s "/ as sysdba" | tr -d \' \')
v_hosts_cvu=$(echo $v_hosts | sed \'s/[\t ]/,/g\')

# Check if the db snapshot controlfile configuration exists
if [[  -n "$v_snapcf_loc" ]] ; then

  v_snapcf_dirname=$(dirname $v_snapcf_loc)

  # get the storage location type: / means file system, + means in ASM
  v_snapcf_loc_type=$(echo $v_snapcf_dirname | $v_awk \'{print substr($0,1,1)}\')

  # check if the location is not empty and on a file system
  if [[  -n "$v_snapcf_loc_type" ]] && [[ "$v_snapcf_loc_type" = "/" ]] ; then
   # cvu to validate shared storageness 
    cvu_report_command=$($ORACLE_HOME/bin/cluvfy comp ssa -s $v_snapcf_dirname -n $v_hosts_cvu -display_status 2>&1)

   # check the status of last command. 0 means pass 
    if [[ $(echo $?) -eq 0 ]] ; then
      v_is_loc_shared=0
      report_command=$(echo "${report_command}\nSnapshot Controlfile is on Shared Filesystem/Directory: $v_snapcf_dirname")
      report_command=$(echo "${report_command}\n $cvu_report_command")
    else
      v_is_loc_shared=1
      report_command=$(echo "${report_command}\nSnapshot Controlfile is not on Shared Filesystem/Directory: $v_snapcf_dirname")
      report_command=$(echo "${report_command}\n $cvu_report_command")
    fi

  else
    # on ASM
    v_is_loc_shared=0
    report_command=$(echo "${report_command}\nSnapshot Controlfile is on ASM Disk Group/Directory: $v_snapcf_dirname")
  fi
else
 v_is_loc_shared=1
 report_command=$(echo "${report_command}\nSnapshot Controlfile is not created because: select distinct value from v\$rman_configuration where name=\'SNAPSHOT CONTROLFILE NAME\' did not return any value.")
fi

echo $v_is_loc_shared
echo DELIMCOM;echo -e "$report_command"
if [ -n "$rat_exitcode" ]; then exit $rat_exitcode; else exit 0;fi
'''
(proc_out,proc_err,rat_exitcode) = secure.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash')
# Debug Extract
secure.logger.info((proc_out,proc_err,rat_exitcode))
proc_out2 = ''
try:
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    print(proc_out1)
except:
    print(proc_out)
with open('/home/oracle/.orachk_071724_093311/orachk_071724_093311/5C413530675BC12CE053D498EB0A3C84_rac2_report.out', 'a', encoding = 'utf-8') as fw:
    fw.write(proc_out2)
if ALVL is not None:
    localcmdval="ALVL = "+ALVL
if rat_exitcode is not None:
    sys.exit(rat_exitcode)
else:
    sys.exit(0)
