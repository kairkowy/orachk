<PYTHON_PATH>
from __future__ import print_function, unicode_literals
import os
import sys
sys.dont_write_bytecode = True
import time
sys.path.insert(0, '<NSPATH>')
from lib.constant import Constants
conobj = Constants()
from lib.security import Secure
import lib.logger
_logger = lib.logger.Log()
_logger = _logger.set_logger("__main__", '/u01/app/oracle/orachk//orachk_071724_093311/orachk.log', 'INFO', '')
secobj = Secure(arg_logger = _logger)

os.environ["ORACLE_HOME"] = "/u01/app/oracle/product/19c/db_1"
os.environ["CRS_HOME"] = "/u01/app/19c/grid"
os.environ["TMPDIR"] = "/home/oracle/.orachk_071724_093311/"
RTEMPDIR = "/home/oracle/.orachk_071724_093311/"
os.environ["SWITCH_TYPE_FIL"] = "/u01/app/oracle/orachk//orachk_071724_093311/switch_ip_type_name_mapping_detail.out"
os.environ["OUTPUTDIR"] = "/u01/app/oracle/orachk//orachk_071724_093311/"
os.environ["ORACLE_SID"] = "racdb1"
Constants.PROGRAM_NAME = 'orachk'
Constants.FDS = '071724_093311'

strval="Wed Jul 17 09:37:17 KST 2024 - STARTED ON rac1"
with open(conobj.catfil(RTEMPDIR,'o_root_collect_timing.out'), 'a', encoding = 'utf-8') as fw:
    fw.write(strval+'\n')

try:
    secobj.logger.info("\n")
    COMSBSTR = '''status=0;for host in $($CRS_HOME/bin/olsnodes |grep -v $(hostname -s)); do netnames=$($CRS_HOME/bin/oifcfg getif|awk \'{print $1}\'|uniq); for netname in $netnames; do /sbin/arping -b -f -c 1 -w 1 -I $netname $host >/dev/null 2>&1; if [ $? -ne 0 ]; then status=1;break;else status=0;fi ; done; done;echo "broadcast_status = $status"'''
    COLLECTION_NAME = "Broadcast Requirements for Networks"
    with open('/home/oracle/.orachk_071724_093311/o_arping_broadcast_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR BROADCAST REQUIREMENTS FOR NETWORKS\n\n\n")
    print(" Collecting - Broadcast Requirements for Networks")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
status=0;for host in $($CRS_HOME/bin/olsnodes |grep -v $(hostname -s)); do netnames=$($CRS_HOME/bin/oifcfg getif|awk \'{print $1}\'|uniq); for netname in $netnames; do /sbin/arping -b -f -c 1 -w 1 -I $netname $host >/dev/null 2>&1; if [ $? -ne 0 ]; then status=1;break;else status=0;fi ; done; done;echo "broadcast_status = $status"    
echo DELIMCOM;status=0;for host in $($CRS_HOME/bin/olsnodes |grep -v $(hostname -s)); do netnames=$($CRS_HOME/bin/oifcfg getif|awk \'{print $1}\'|uniq); for netname in $netnames; do /sbin/arping -b -f -c 1 -w 1 -I $netname $host; done; done    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_arping_broadcast.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_arping_broadcast.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_arping_broadcast_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''echo "opatchversion = $($CRS_HOME/OPatch/opatch version|grep -i version|awk \'{print $3}\'|sed \'s/\.//g\')"'''
    COLLECTION_NAME = "CRS Opatch version"
    with open('/home/oracle/.orachk_071724_093311/o_opatchversion_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR CRS OPATCH VERSION\n\n\n")
    print(" Collecting - CRS Opatch version")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
echo "opatchversion = $($CRS_HOME/OPatch/opatch version|grep -i version|awk \'{print $3}\'|sed \'s/\.//g\')"    
echo DELIMCOM; $CRS_HOME/OPatch/opatch version|grep -i version    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_opatchversion.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_opatchversion.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_opatchversion_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''su - `grep \'ORACLE_OWNER=\' $CRS_HOME/crs/install/crsconfig_params|head -1|cut -d= -f2` -c "date \'+%Z\'"|tail -1'''
    COLLECTION_NAME = "CRS user time zone check"
    with open('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_crs_time_zone_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR CRS USER TIME ZONE CHECK\n\n\n")
    print(" Collecting - CRS user time zone check")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
su - `grep \'ORACLE_OWNER=\' $CRS_HOME/crs/install/crsconfig_params|head -1|cut -d= -f2` -c "date \'+%Z\'"|tail -1    
echo DELIMCOM;su - `grep \'ORACLE_OWNER=\' $CRS_HOME/crs/install/crsconfig_params|head -1|cut -d= -f2` -c "date \'+%Z\'"|tail -1    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_crs_time_zone.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_crs_time_zone.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_crs_time_zone_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''cat /etc/rc.local'''
    COLLECTION_NAME = "Custom rc init scripts (rc.local)"
    with open('/home/oracle/.orachk_071724_093311/o_rclocal_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR CUSTOM RC INIT SCRIPTS (RC.LOCAL)\n\n\n")
    print(" Collecting - Custom rc init scripts (rc.local)")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
cat /etc/rc.local    
echo DELIMCOM;cat /etc/rc.local    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_rclocal.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_rclocal.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_rclocal_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''output=$(/sbin/fdisk -l 2>&1);echo "$output"'''
    COLLECTION_NAME = "Disk Information"
    with open('/home/oracle/.orachk_071724_093311/o_disk_info_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR DISK INFORMATION\n\n\n")
    print(" Collecting - Disk Information")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
output=$(/sbin/fdisk -l 2>&1);echo "$output"    
echo DELIMCOM;output=$(/sbin/fdisk -l 2>&1);echo "$output"    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_disk_info.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_disk_info.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_disk_info_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''user=$(ls -l $CRS_HOME/bin/ocssd.bin |awk \'{print $3}\');soft_limits_raw=$(su - $user -c "ulimit -Sa");hard_limits_raw=$(su - $user -c "ulimit -Ha");soft_limits=$(echo "$soft_limits_raw"|awk \'{print "soft_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');hard_limits=$(echo "$hard_limits_raw"|awk \'{print "hard_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');echo -e "$soft_limits \n\n$hard_limits"'''
    COLLECTION_NAME = "Grid Infastructure user shell limits configuration"
    with open('/home/oracle/.orachk_071724_093311/o_crs_user_limits_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR GRID INFASTRUCTURE USER SHELL LIMITS CONFIGURATION\n\n\n")
    print(" Collecting - Grid Infastructure user shell limits configuration")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
user=$(ls -l $CRS_HOME/bin/ocssd.bin |awk \'{print $3}\');soft_limits_raw=$(su - $user -c "ulimit -Sa");hard_limits_raw=$(su - $user -c "ulimit -Ha");soft_limits=$(echo "$soft_limits_raw"|awk \'{print "soft_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');hard_limits=$(echo "$hard_limits_raw"|awk \'{print "hard_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');echo -e "$soft_limits \n\n$hard_limits"    
echo DELIMCOM;user=$(ls -l $CRS_HOME/bin/ocssd.bin |awk \'{print $3}\');soft_limits_raw=$(su - $user -c "ulimit -Sa");hard_limits_raw=$(su - $user -c "ulimit -Ha");echo -e "Soft limits(ulimit -Sa) \n\n$soft_limits_raw \n\n\nHard Limits(ulimit -Ha)\n\n$hard_limits_raw"    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_crs_user_limits.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_crs_user_limits.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_crs_user_limits_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = ''' for i in `$CRS_HOME/bin/oifcfg getif |awk {\'print $1\'}`; do echo $i.Speed = `/sbin/ethtool $i |grep Speed: |awk {\'print $2\'}`;echo $i.Duplex =  `/sbin/ethtool $i |grep Duplex: |awk {\'print $2\'}`;echo $i.Auto-Neg = `/sbin/ethtool $i |grep Auto-negotiation:  |awk {\'print $2\'}`;echo $i.RX = `/sbin/ethtool -a $i 2>/dev/null|grep RX|awk \'{print $2}\'`; echo $i.TX = `/sbin/ethtool -a $i 2>/dev/null|grep TX|awk \'{print $2}\'`;done'''
    COLLECTION_NAME = "Interconnect interface config"
    with open('/home/oracle/.orachk_071724_093311/o_rac_if_config_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR INTERCONNECT INTERFACE CONFIG\n\n\n")
    print(" Collecting - Interconnect interface config")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
 for i in `$CRS_HOME/bin/oifcfg getif |awk {\'print $1\'}`; do echo $i.Speed = `/sbin/ethtool $i |grep Speed: |awk {\'print $2\'}`;echo $i.Duplex =  `/sbin/ethtool $i |grep Duplex: |awk {\'print $2\'}`;echo $i.Auto-Neg = `/sbin/ethtool $i |grep Auto-negotiation:  |awk {\'print $2\'}`;echo $i.RX = `/sbin/ethtool -a $i 2>/dev/null|grep RX|awk \'{print $2}\'`; echo $i.TX = `/sbin/ethtool -a $i 2>/dev/null|grep TX|awk \'{print $2}\'`;done    
echo DELIMCOM;for i in `$CRS_HOME/bin/oifcfg getif |awk {\'print $1\'}`; do echo $i.Speed = `/sbin/ethtool $i |grep Speed: |awk {\'print $2\'}`;echo $i.Duplex =  `/sbin/ethtool $i |grep Duplex: |awk {\'print $2\'}`;echo $i.Auto-Neg = `/sbin/ethtool $i |grep Auto-negotiation:  |awk {\'print $2\'}`;echo $i.RX = `/sbin/ethtool -a $i 2>/dev/null|grep RX|awk \'{print $2}\'`; echo $i.TX = `/sbin/ethtool -a $i 2>/dev/null|grep TX|awk \'{print $2}\'`;done    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_rac_if_config.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_rac_if_config.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_rac_if_config_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''for i in `/bin/netstat -i |grep -v Kernel |grep -v Iface |grep -v lo |awk \'{print $1}\'`; do /sbin/ethtool -S $i 2>/dev/nulli; done'''
    COLLECTION_NAME = "Network interface stats"
    with open('/home/oracle/.orachk_071724_093311/o_ethtool-s_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR NETWORK INTERFACE STATS\n\n\n")
    print(" Collecting - Network interface stats")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
for i in `/bin/netstat -i |grep -v Kernel |grep -v Iface |grep -v lo |awk \'{print $1}\'`; do /sbin/ethtool -S $i 2>/dev/nulli; done    
echo DELIMCOM;for i in `/bin/netstat -i |grep -v Kernel |grep -v Iface |grep -v lo |awk \'{print $1}\'`; do /sbin/ethtool -S $i 2>/dev/nulli; done    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_ethtool-s.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_ethtool-s.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_ethtool-s_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''DMN_DIR=$(file ${HOME}/.*achk_${USER}_s | cut -d ":" -f1)      
dmn_running=$(ps -ef | grep "scheduler_daemon 1" | grep "python" | wc -l)      
dmn_active=$(if [[ -f "$DMN_DIR/autoscheduler.py" ]]; then echo "1"; else echo "0"; fi)      
      
mkstorebin="${CRS_HOME}/bin/mkstore"    
if [[ ! -x $mkstorebin ]]; then mkstorebin="${ORACLE_HOME}/bin/mkstore"; fi    
    
if [[ "$dmn_running" -ge "1" && "$dmn_active" == "1" ]]; then      
    walletloc=$(cat $DMN_DIR/.*achk_scheduler.mdf | grep "WALLET LOCATION" | cut -d ":" -f2)      
    mkstorecmd="$mkstorebin -wrl $walletloc -nologo"      
    autorunIDs=$($mkstorecmd -list | grep "AUTORUN_ID_")      
    for cId in $autorunIDs; do echo "$($mkstorecmd -viewEntry $cId)"; done      
fi      '''
    COLLECTION_NAME = "ORAchk Daemon/Scheduler configuration"
    with open('/home/oracle/.orachk_071724_093311/o_orachk_daemon_conf_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR ORACHK DAEMON/SCHEDULER CONFIGURATION\n\n\n")
    print(" Collecting - ORAchk Daemon/Scheduler configuration")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
DMN_DIR=$(file ${HOME}/.*achk_${USER}_s | cut -d ":" -f1)      
dmn_running=$(ps -ef | grep "scheduler_daemon 1" | grep "python" | wc -l)      
dmn_active=$(if [[ -f "$DMN_DIR/autoscheduler.py" ]]; then echo "1"; else echo "0"; fi)      
      
mkstorebin="${CRS_HOME}/bin/mkstore"    
if [[ ! -x $mkstorebin ]]; then mkstorebin="${ORACLE_HOME}/bin/mkstore"; fi    
    
if [[ "$dmn_running" -ge "1" && "$dmn_active" == "1" ]]; then      
    walletloc=$(cat $DMN_DIR/.*achk_scheduler.mdf | grep "WALLET LOCATION" | cut -d ":" -f2)      
    mkstorecmd="$mkstorebin -wrl $walletloc -nologo"      
    autorunIDs=$($mkstorecmd -list | grep "AUTORUN_ID_")      
    for cId in $autorunIDs; do echo "$($mkstorecmd -viewEntry $cId)"; done      
fi          
echo DELIMCOM;    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_orachk_daemon_conf.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_orachk_daemon_conf.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_orachk_daemon_conf_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''soft_limits_raw=$(ulimit -Sa);hard_limits_raw=$(ulimit -Ha);soft_limits=$(echo "$soft_limits_raw"|awk \'{print "soft_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');hard_limits=$(echo "$hard_limits_raw"|awk \'{print "hard_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');echo -e "$soft_limits \n\n$hard_limits"'''
    COLLECTION_NAME = "Root user limits"
    with open('/home/oracle/.orachk_071724_093311/o_root_user_limits_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR ROOT USER LIMITS\n\n\n")
    print(" Collecting - Root user limits")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
soft_limits_raw=$(ulimit -Sa);hard_limits_raw=$(ulimit -Ha);soft_limits=$(echo "$soft_limits_raw"|awk \'{print "soft_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');hard_limits=$(echo "$hard_limits_raw"|awk \'{print "hard_"$1"_"$2 " = "$NF}\'|sed \'s/unlimited/9999999999999/g\');echo -e "$soft_limits \n\n$hard_limits"    
echo DELIMCOM;soft_limits_raw=$(ulimit -Sa);hard_limits_raw=$(ulimit -Ha);echo -e "Soft limits(ulimit -Sa) \n\n$soft_limits_raw \n\n\nHard Limits(ulimit -Ha)\n\n$hard_limits_raw"    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_root_user_limits.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_root_user_limits.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_root_user_limits_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''CurDate=$(date +"%b %d %T");PreDate=$(date +"%b %d %T" --date="1 day ago"); error_count=$(awk \'$0>=from&&$0<=to\' from="$PreDate" to="$CurDate" /var/log/messages | grep oom_kill_process | wc -l); if [ $error_count -ne 0 ]; then error_status=1; else error_status=0; fi; echo "kernel_oom_errors_status = $error_status"'''
    COLLECTION_NAME = "Verify no database server kernel out of memory errors "
    with open('/home/oracle/.orachk_071724_093311/o_kernel_oom_errors_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR VERIFY NO DATABASE SERVER KERNEL OUT OF MEMORY ERRORS \n\n\n")
    print(" Collecting - Verify no database server kernel out of memory errors ")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
CurDate=$(date +"%b %d %T");PreDate=$(date +"%b %d %T" --date="1 day ago"); error_count=$(awk \'$0>=from&&$0<=to\' from="$PreDate" to="$CurDate" /var/log/messages | grep oom_kill_process | wc -l); if [ $error_count -ne 0 ]; then error_status=1; else error_status=0; fi; echo "kernel_oom_errors_status = $error_status"    
echo DELIMCOM;CurDate=$(date +"%b %d %T"); PreDate=$(date +"%b %d %T" --date="1 day ago"); error_log=$(awk \'$0>=from&&$0<=to\' from="$PreDate" to="$CurDate" /var/log/messages | grep oom_kill_process); error_count=$(awk \'$0>=from&&$0<=to\' from="$PreDate" to="$CurDate" /var/log/messages | grep oom_kill_process | wc -l); echo "There are $error_count out-of-memory errors within the last 24 hours. They are found in /var/log/messages. The detailed error messages for the past 24 hours are $error_log."    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_kernel_oom_errors.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_kernel_oom_errors.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_kernel_oom_errors_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''date \'+%Z\'|tail -1'''
    COLLECTION_NAME = "root time zone check"
    with open('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_root_time_zone_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR ROOT TIME ZONE CHECK\n\n\n")
    print(" Collecting - root time zone check")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
date \'+%Z\'|tail -1    
echo DELIMCOM;date \'+%Z\'    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_root_time_zone.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_root_time_zone.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_root_clusterwide_check_root_time_zone_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''cat /proc/slabinfo'''
    COLLECTION_NAME = "slabinfo"
    with open('/home/oracle/.orachk_071724_093311/o_slabinfo_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR SLABINFO\n\n\n")
    print(" Collecting - slabinfo")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
cat /proc/slabinfo    
echo DELIMCOM;cat /proc/slabinfo    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_slabinfo.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_slabinfo.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_slabinfo_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass

try:
    secobj.logger.info("\n")
    COMSBSTR = '''user=$(ls -l $CRS_HOME/bin/ocssd.bin |awk \'{print $3}\');umask=$(su - $user -c "umask"); umask=$(echo $umask|awk \'{print $NF}\');echo umask = $umask   '''
    COLLECTION_NAME = "umask setting for GI owner"
    with open('/home/oracle/.orachk_071724_093311/o_gi_umask_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write("\nTO REVIEW COLLECTED DATA FROM RAC1 FOR UMASK SETTING FOR GI OWNER\n\n\n")
    print(" Collecting - umask setting for GI owner")
    host = "rac1"
    ROOT_COLLECT_TIMING = "/home/oracle/.orachk_071724_093311/o_root_collect_timing.out"
    with open(ROOT_COLLECT_TIMING, 'a', encoding = 'utf-8') as fw:
        fw.write(time.strftime("%a %b %d %H:%M:%S %Z %Y") +  ' - ' + COLLECTION_NAME + ' on ' + host + '\n')
    ALVL = ''''''
    native_code = '''
user=$(ls -l $CRS_HOME/bin/ocssd.bin |awk \'{print $3}\');umask=$(su - $user -c "umask"); umask=$(echo $umask|awk \'{print $NF}\');echo umask = $umask       
echo DELIMCOM;user=$(ls -l $CRS_HOME/bin/ocssd.bin |awk \'{print $3}\');umask=$(su $user -c "umask"); echo umask = $umask    '''
    (proc_out,proc_err,rat_exitcode) = secobj.sync_subprocess(native_code, return_code_from_task = True, executable = '/usr/bin/bash', timeout = 90)
    proc_outval = proc_out.split("DELIMCOM")
    proc_out1 = proc_outval[0]
    proc_out2 = proc_outval[1]
    with open('/home/oracle/.orachk_071724_093311/o_gi_umask.out', 'a', encoding = 'utf-8') as fw:
        fw.write( proc_out1)
    os.chown('/home/oracle/.orachk_071724_093311/o_gi_umask.out', 54321, 54321)
    with open('/home/oracle/.orachk_071724_093311/o_gi_umask_report.out', 'a', encoding = 'utf-8') as fw:
        fw.write(proc_out2)
except Exception as err:
    print(err)
finally:
    pass
RTEMPDIR = '''/home/oracle/.orachk_071724_093311/'''
usern = '''oracle'''
path = '''/home/oracle/.orachk_071724_093311/'''
EPATH = '''/home/oracle/.orachk_071724_093311'''
try:
    import pwd
    import grp
    import re
    uid = pwd.getpwnam(usern).pw_uid
    gid = pwd.getpwnam(usern).pw_gid
    for root,dirs,files in os.walk(path):
        if (re.search(EPATH, root)): continue
        for momo in dirs:
            os.chown(os.path.join(root, momo), uid, gid)
        for momo in files:
            os.chown(os.path.join(root, momo), uid, gid)
except: pass
