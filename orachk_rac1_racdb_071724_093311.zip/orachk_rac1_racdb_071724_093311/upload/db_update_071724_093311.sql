Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 
Unexpected argument log_result [1] = 

